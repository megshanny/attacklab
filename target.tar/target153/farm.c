/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_326(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_472(unsigned x)
{
    return x + 3284633928U;
}

void setval_344(unsigned *p)
{
    *p = 1479445756U;
}

void setval_295(unsigned *p)
{
    *p = 3351742792U;
}

unsigned addval_441(unsigned x)
{
    return x + 3284633930U;
}

void setval_242(unsigned *p)
{
    *p = 1358762229U;
}

void setval_264(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_243(unsigned x)
{
    return x + 3264239855U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_109(unsigned x)
{
    return x + 3380924681U;
}

unsigned addval_228(unsigned x)
{
    return x + 2463009097U;
}

void setval_465(unsigned *p)
{
    *p = 3281047949U;
}

unsigned getval_353()
{
    return 3674784409U;
}

void setval_158(unsigned *p)
{
    *p = 2425671305U;
}

void setval_339(unsigned *p)
{
    *p = 3767093374U;
}

void setval_495(unsigned *p)
{
    *p = 3230974601U;
}

unsigned addval_167(unsigned x)
{
    return x + 2430634304U;
}

void setval_358(unsigned *p)
{
    *p = 3267529061U;
}

unsigned addval_189(unsigned x)
{
    return x + 3286272264U;
}

unsigned getval_128()
{
    return 3523789449U;
}

unsigned getval_447()
{
    return 3525366025U;
}

unsigned addval_349(unsigned x)
{
    return x + 3221802635U;
}

unsigned getval_256()
{
    return 3230974601U;
}

void setval_445(unsigned *p)
{
    *p = 2429454766U;
}

unsigned getval_132()
{
    return 3678981769U;
}

void setval_367(unsigned *p)
{
    *p = 3224948361U;
}

unsigned getval_356()
{
    return 3286273352U;
}

unsigned getval_177()
{
    return 3682910857U;
}

void setval_216(unsigned *p)
{
    *p = 3352201634U;
}

unsigned getval_248()
{
    return 2428684735U;
}

void setval_381(unsigned *p)
{
    *p = 3767093386U;
}

void setval_262(unsigned *p)
{
    *p = 2497743176U;
}

void setval_120(unsigned *p)
{
    *p = 3281179017U;
}

unsigned addval_470(unsigned x)
{
    return x + 1237569929U;
}

void setval_268(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_468()
{
    return 3281047961U;
}

unsigned addval_407(unsigned x)
{
    return x + 3281043977U;
}

void setval_289(unsigned *p)
{
    *p = 3526939033U;
}

void setval_321(unsigned *p)
{
    *p = 3464571154U;
}

unsigned getval_376()
{
    return 3286272360U;
}

void setval_467(unsigned *p)
{
    *p = 3676361097U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
